# Mokepones fight

Three creatures, made of water, fire, and plants respectively, fight for the honor of their family. Any similarity with other games is pure coincidence 😄.
